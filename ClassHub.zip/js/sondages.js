import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import { collection, query, where, onSnapshot, doc, getDoc, updateDoc, increment } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

onAuthStateChanged(auth, async (user) => {
  if (!user) return;
  const u = await getDoc(doc(db, "users", user.uid));
  if (u.exists()) {
    onSnapshot(query(collection(db, "sondages"), where("classId", "==", u.data().classId)), (s) => {
      const c = document.getElementById("sondages-list"); 
      c.innerHTML = "";

      // Récupération des votes déjà effectués par l'utilisateur
      const votedPolls = JSON.parse(localStorage.getItem(`voted_${user.uid}`) || "[]");

      s.forEach(d => {
        const v = d.data();
        const pollId = d.id;
        const hasVoted = votedPolls.includes(pollId);

        const div = document.createElement("div"); 
        div.className = "card";
        div.innerHTML = `
          <h3>📊 ${v.question}</h3>
          <div style="margin-top:1rem; display:flex; gap:0.5rem; flex-direction:column;">
            <button class="btn btn-secondary opt1" ${hasVoted ? "disabled" : ""}>${v.opt1} (${v.votes1})</button>
            <button class="btn btn-secondary opt2" ${hasVoted ? "disabled" : ""}>${v.opt2} (${v.votes2})</button>
          </div>
          ${hasVoted ? '<p style="color:var(--text-muted); font-size:0.8rem; margin-top:0.5rem; text-align:center;">Vous avez déjà voté</p>' : ''}
        `;

        const btnOpt1 = div.querySelector(".opt1");
        const btnOpt2 = div.querySelector(".opt2");

        const handleVote = async (field) => {
          if (hasVoted) return;
          
          // Mise à jour sur Firestore
          await updateDoc(doc(db, "sondages", pollId), { [field]: increment(1) });
          
          // Enregistrement du vote en local
          votedPolls.push(pollId);
          localStorage.setItem(`voted_${user.uid}`, JSON.stringify(votedPolls));
        };

        btnOpt1.addEventListener("click", () => handleVote("votes1"));
        btnOpt2.addEventListener("click", () => handleVote("votes2"));

        c.appendChild(div);
      });
    });
  }
});
