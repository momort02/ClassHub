import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import { collection, query, where, onSnapshot, doc, getDoc, updateDoc, setDoc, increment, getDocs, addDoc, deleteDoc } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

let currentUser = null;
let currentUserData = null;

onAuthStateChanged(auth, async (user) => {
  if (!user) return;
  currentUser = user;

  const snap = await getDoc(doc(db, "users", user.uid));
  if (snap.exists()) {
    currentUserData = snap.data();
    
    // Vérification et réinitialisation annuelle (1er Septembre)
    await verifierReinitialisationAnnuelle();

    document.getElementById("profil-nom-complet").textContent = `${currentUserData.prenom} ${currentUserData.nom}`;
    document.getElementById("profil-email").textContent = currentUserData.email;
    document.getElementById("profil-classe").value = currentUserData.classe || currentUserData.classId;
    document.getElementById("profil-role").value = currentUserData.role === "delegue" ? "Délégué" : "Élève";
    if (currentUserData.role === "delegue") document.getElementById("btn-delegue").style.display = "flex";

    initElections();
    loadAvis();
  }
});

// Réinitialisation automatique de la base de données le 1er septembre
async function verifierReinitialisationAnnuelle() {
  const now = new Date();
  const currentYear = now.getFullYear();
  const rentreeDate = new Date(currentYear, 8, 1); // 1er Septembre

  // Si on est à partir du 1er septembre
  if (now >= rentreeDate) {
    const classRef = doc(db, "elections_classes", currentUserData.classId);
    const classSnap = await getDoc(classRef);

    // Si la réinitialisation de cette année n'a pas encore eu lieu
    if (!classSnap.exists() || classSnap.data().derniereRentree !== currentYear) {
      console.log(`🧹 Réinitialisation de la classe ${currentUserData.classId} pour la rentrée ${currentYear}...`);

      // 1. Réinitialiser les rôles des élèves de la classe
      const usersQuery = query(collection(db, "users"), where("classId", "==", currentUserData.classId));
      const usersSnap = await getDocs(usersQuery);
      for (const uDoc of usersSnap.docs) {
        await updateDoc(doc(db, "users", uDoc.id), {
          role: "eleve",
          votesElectoraux: 0,
          votesDesignation: 0,
          isCandidat: false
        });
      }

      // 2. Supprimer les votes enregistrés pour cette classe
      const votesQuery = query(collection(db, "elections_votes"), where("classId", "==", currentUserData.classId));
      const votesSnap = await getDocs(votesQuery);
      for (const vDoc of votesSnap.docs) {
        await deleteDoc(doc(db, "elections_votes", vDoc.id));
      }

      // 3. Supprimer les candidatures en binômes
      const binomesQuery = query(collection(db, "binomes_candidats"), where("classId", "==", currentUserData.classId));
      const binomesSnap = await getDocs(binomesQuery);
      for (const bDoc of binomesSnap.docs) {
        await deleteDoc(doc(db, "binomes_candidats", bDoc.id));
      }

      // 4. Mettre à jour le statut d'élection de la classe pour la nouvelle année
      await setDoc(classRef, {
        classId: currentUserData.classId,
        tour: 1,
        statut: "en_cours",
        modeDesignation: false,
        derniereRentree: currentYear
      });

      console.log("✅ Réinitialisation annuelle effectuée !");
    }
  }
}

async function initElections() {
  const now = new Date();
  const year = now.getFullYear();
  const startDate = new Date(year, 8, 15); // 15 Septembre
  const endDate = new Date(year, 9, 1);    // 1er Octobre

  const statusMsg = document.getElementById("election-status-msg");
  const candBox = document.getElementById("election-candidature-box");
  const voteBox = document.getElementById("election-vote-box");

  if (now < startDate) {
    statusMsg.textContent = `Les élections ouvriront le 15 septembre ${year}.`;
    return;
  }

  const electionRef = doc(db, "elections_classes", currentUserData.classId);
  const electionSnap = await getDoc(electionRef);

  let tourActuel = 1;
  let modeDesignation = false;

  if (electionSnap.exists()) {
    tourActuel = electionSnap.data().tour || 1;
    modeDesignation = electionSnap.data().modeDesignation || false;
    if (electionSnap.data().statut === "termine") {
      statusMsg.textContent = "Élections terminées. Les 2 binômes de délégués ont été nommés.";
      return;
    }
  }

  const usersQuery = query(collection(db, "users"), where("classId", "==", currentUserData.classId));
  const usersSnap = await getDocs(usersQuery);
  const totalEleves = usersSnap.size;

  const binomesQuery = query(collection(db, "binomes_candidats"), 
    where("classId", "==", currentUserData.classId),
    where("tourQualifie", "==", tourActuel)
  );
  const binomesSnap = await getDocs(binomesQuery);

  const selectSupp = document.getElementById("select-suppleant");
  if (selectSupp) {
    selectSupp.innerHTML = '<option value="">-- Sélectionner un élève --</option>';
    usersSnap.forEach((d) => {
      const u = d.data();
      if (u.uid !== currentUser.uid) {
        selectSupp.innerHTML += `<option value="${u.uid}">${u.prenom} ${u.nom}</option>`;
      }
    });
  }

  if (binomesSnap.empty && (now >= endDate || modeDesignation)) {
    if (!modeDesignation) {
      await updateDoc(electionRef, { modeDesignation: true });
    }
    statusMsg.textContent = "⚠️ Aucun candidat ne s'est présenté. La classe doit désigner d'office 2 binômes !";
    candBox.style.display = "none";
    voteBox.style.display = "block";
    afficherModeDesignation(usersSnap);
    return;
  }

  const votesQuery = query(collection(db, "elections_votes"), 
    where("classId", "==", currentUserData.classId),
    where("tour", "==", tourActuel)
  );
  const votesSnap = await getDocs(votesQuery);
  const totalVotesCount = votesSnap.size;
  const hasVoted = votesSnap.docs.some(d => d.data().voterUid === currentUser.uid);

  document.getElementById("tour-titre").textContent = `Élection de 2 Binômes - ${tourActuel === 1 ? "1er Tour (Majorité absolue)" : "2nd Tour (Majorité relative)"}`;
  statusMsg.textContent = `${tourActuel}${tourActuel === 1 ? 'er' : 'nd'} Tour : ${totalVotesCount}/${totalEleves} élèves ont voté. (2 binômes seront élus).`;

  candBox.style.display = tourActuel === 1 ? "block" : "none";
  voteBox.style.display = "block";

  const btnCreer = document.getElementById("btn-creer-binome");
  if (btnCreer) {
    btnCreer.onclick = async () => {
      const suppUid = selectSupp.value;
      if (!suppUid) return alert("Sélectionnez un suppléant.");

      const suppSnap = await getDoc(doc(db, "users", suppUid));
      const suppData = suppSnap.data();

      await addDoc(collection(db, "binomes_candidats"), {
        classId: currentUserData.classId,
        titulaireUid: currentUser.uid,
        titulaireNom: `${currentUserData.prenom} ${currentUserData.nom}`,
        suppleantUid: suppUid,
        suppleantNom: `${suppData.prenom} ${suppData.nom}`,
        votesTour1: 0,
        votesTour2: 0,
        tourQualifie: 1
      });

      alert("Votre binôme est bien inscrit pour l'élection !");
      location.reload();
    };
  }

  const candList = document.getElementById("candidats-list");
  candList.innerHTML = "";

  binomesSnap.forEach((d) => {
    const b = d.data();
    const btnVote = document.createElement("button");
    btnVote.className = "btn btn-secondary";
    btnVote.style.cssText = "width:100%; margin-bottom:0.8rem; justify-content:space-between; text-align:left; padding:0.8rem;";
    btnVote.disabled = hasVoted;

    btnVote.innerHTML = `
      <div>
        <strong>Titulaire:</strong> ${b.titulaireNom}<br>
        <small style="color:var(--text-muted);">Suppléant: ${b.suppleantNom}</small>
      </div>
      <span>${hasVoted ? "A voté" : "Voter 👍"}</span>
    `;

    btnVote.onclick = async () => {
      if (hasVoted) return;

      const voteField = tourActuel === 1 ? "votesTour1" : "votesTour2";
      await updateDoc(doc(db, "binomes_candidats", d.id), { [voteField]: increment(1) });
      
      await setDoc(doc(db, "elections_votes", `${currentUser.uid}_T${tourActuel}_${currentUserData.classId}`), {
        classId: currentUserData.classId,
        voterUid: currentUser.uid,
        tour: tourActuel,
        votedAt: new Date()
      });

      alert("Vote anonyme enregistré !");
      location.reload();
    };

    candList.appendChild(btnVote);
  });

  if (candList.children.length === 0) {
    candList.innerHTML = "<p style='font-style:italic; font-size:0.85rem;'>Aucun binôme candidat pour l'instant.</p>";
  }

  if (totalEleves > 0 && totalVotesCount >= totalEleves) {
    depouillerElections(tourActuel, binomesSnap, totalVotesCount);
  }
}

async function depouillerElections(tour, binomesSnap, totalVotes) {
  let binomes = [];
  binomesSnap.forEach(d => binomes.push({ id: d.id, ...d.data() }));

  if (tour === 1) {
    binomes.sort((a, b) => b.votesTour1 - a.votesTour1);
    const majoriteAbsolue = Math.floor(totalVotes / 2) + 1;

    if (binomes.length >= 2 && binomes[0].votesTour1 >= majoriteAbsolue && binomes[1].votesTour1 >= majoriteAbsolue) {
      await nommer2BinomesGagnants(binomes[0], binomes[1]);
    } else {
      for (let i = 0; i < Math.min(4, binomes.length); i++) {
        await updateDoc(doc(db, "binomes_candidats", binomes[i].id), { tourQualifie: 2 });
      }
      await updateDoc(doc(db, "elections_classes", currentUserData.classId), { tour: 2 });
      alert("Ouverture du 2nd tour pour élire les 2 binômes !");
      location.reload();
    }
  } else if (tour === 2) {
    binomes.sort((a, b) => b.votesTour2 - a.votesTour2);
    if (binomes.length >= 2) {
      await nommer2BinomesGagnants(binomes[0], binomes[1]);
    } else if (binomes.length === 1) {
      await nommer1BinomeGagnant(binomes[0]);
    }
  }
}

async function nommer2BinomesGagnants(b1, b2) {
  await updateDoc(doc(db, "users", b1.titulaireUid), { role: "delegue" });
  await updateDoc(doc(db, "users", b1.suppleantUid), { role: "delegue" });
  await updateDoc(doc(db, "users", b2.titulaireUid), { role: "delegue" });
  await updateDoc(doc(db, "users", b2.suppleantUid), { role: "delegue" });

  await updateDoc(doc(db, "elections_classes", currentUserData.classId), { statut: "termine" });
  alert("Élection terminée ! Les 2 binômes de délégués ont été officiellement élus.");
  location.reload();
}

async function nommer1BinomeGagnant(b1) {
  await updateDoc(doc(db, "users", b1.titulaireUid), { role: "delegue" });
  await updateDoc(doc(db, "users", b1.suppleantUid), { role: "delegue" });

  await updateDoc(doc(db, "elections_classes", currentUserData.classId), { statut: "termine" });
  alert("Élection terminée ! Le binôme a été élu.");
  location.reload();
}

function afficherModeDesignation(usersSnap) {
  const candList = document.getElementById("candidats-list");
  candList.innerHTML = "<p style='font-size:0.85rem; margin-bottom:1rem;'>Votez pour l'élève que vous souhaitez désigner comme délégué d'office :</p>";

  usersSnap.forEach((d) => {
    const u = d.data();
    const btnDesign = document.createElement("button");
    btnDesign.className = "btn btn-secondary";
    btnDesign.style.cssText = "width:100%; margin-bottom:0.5rem; justify-content:space-between;";
    btnDesign.innerHTML = `<span>${u.prenom} ${u.nom}</span> <span>Désigner 🗳️</span>`;

    btnDesign.onclick = async () => {
      await updateDoc(doc(db, "users", d.id), { votesDesignation: increment(1) });
      alert(`Votre désignation pour ${u.prenom} a été enregistrée.`);
      location.reload();
    };
    candList.appendChild(btnDesign);
  });
}

function loadAvis() {
  const q = query(collection(db, "avis_profs"), where("eleveUid", "==", currentUser.uid));
  onSnapshot(q, (snapshot) => {
    const container = document.getElementById("liste-avis-container");
    container.innerHTML = "";
    if (snapshot.empty) {
      container.innerHTML = `<p style="color:var(--text-muted); font-style:italic;">Aucun avis enregistré.</p>`;
      return;
    }
    snapshot.forEach((d) => {
      const data = d.data();
      container.innerHTML += `
        <div class="card" style="background:var(--bg-tertiary); margin-bottom:0.8rem;">
          <strong style="color:var(--accent);">${data.periode}</strong>
          <p style="margin-top:0.4rem;">"${data.avis}"</p>
        </div>`;
    });
  });
}