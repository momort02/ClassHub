import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, doc, getDoc, updateDoc, increment } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

let currentUser = null;

onAuthStateChanged(auth, async (user) => {
  if (!user) { window.location.href = "login.html"; return; }
  const snap = await getDoc(doc(db, "users", user.uid));
  if (snap.exists()) { currentUser = snap.data(); listenDemandes(user.uid); }
});

document.getElementById("btn-logout")?.addEventListener("click", () => signOut(auth));

const modal = document.getElementById("modal-demande");
document.getElementById("btn-open-modal")?.addEventListener("click", () => modal.classList.add("active"));
document.getElementById("btn-close-modal")?.addEventListener("click", () => modal.classList.remove("active"));

document.getElementById("form-demande")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  await addDoc(collection(db, "demandes"), {
    titre: document.getElementById("demande-titre").value,
    categorie: document.getElementById("demande-categorie").value,
    description: document.getElementById("demande-description").value,
    authorName: `${currentUser.prenom} ${currentUser.nom}`,
    classId: currentUser.classId,
    statut: "En attente", votes: 0, createdAt: serverTimestamp()
  });
  modal.classList.remove("active");
  e.target.reset();
});

function listenDemandes(uid) {
  const q = query(collection(db, "demandes"), where("classId", "==", currentUser.classId));
  
  onSnapshot(q, (snapshot) => {
    const c = document.getElementById("demandes-list");
    c.innerHTML = "";
    
    // Récupération des demandes déjà likées par l'utilisateur
    const votedDemandes = JSON.parse(localStorage.getItem(`voted_demandes_${uid}`) || "[]");

    snapshot.forEach((d) => {
      const data = d.data();
      const demandeId = d.id;
      const hasVoted = votedDemandes.includes(demandeId);
      const badge = `badge-${data.statut.toLowerCase().replace(" ", "-")}`;

      c.innerHTML += `
        <div class="card">
          <div class="card-header">
            <div class="card-title">${data.titre}</div>
            <span class="badge ${badge}">${data.statut}</span>
          </div>
          <p style="color: var(--text-muted); font-size:0.9rem;">${data.description}</p>
          <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem;">
            <small style="color:var(--accent);">${data.categorie}</small>
            <button class="btn btn-secondary btn-vote" data-id="${demandeId}" ${hasVoted ? "disabled" : ""} style="padding: 6px 12px; font-size: 0.9rem;">
              👍 ${data.votes} ${hasVoted ? "(Voté)" : ""}
            </button>
          </div>
        </div>`;
    });

    // Gestion des clics sur les boutons de vote
    document.querySelectorAll(".btn-vote").forEach(b => {
      b.addEventListener("click", async (e) => {
        const btn = e.currentTarget;
        const demandeId = btn.dataset.id;
        
        if (votedDemandes.includes(demandeId)) return;

        // Mise à jour sur Firestore
        await updateDoc(doc(db, "demandes", demandeId), { votes: increment(1) });

        // Enregistrement du vote en local
        votedDemandes.push(demandeId);
        localStorage.setItem(`voted_demandes_${uid}`, JSON.stringify(votedDemandes));
      });
    });
  });
}
